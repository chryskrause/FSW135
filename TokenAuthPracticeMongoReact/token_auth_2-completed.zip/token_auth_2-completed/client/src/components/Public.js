import React from 'react'
import TodoList from './TodoList.js'
import Todo from './Todo.js'

export default function Public(){
  return (
    <div className="public">

    </div>
  )
}