# rlm-token-auth-series-context

## Commands to clone the specific sections:
  ### Part 1 start:
    * git clone -b part-1-start https://github.com/v-school/rlm-token-auth-series-context.git
    * cd rlm-token-auth-series-context
    * code .
    * run npm install to get dependencies

  ### Part 1 end:
    * git clone -b part-1-end https://github.com/v-school/rlm-token-auth-series-context.git
    * cd rlm-token-auth-series-context
    * code .
    * run npm install to get dependencies

  ### Part 2 start:
    * git clone -b part-2-start https://github.com/v-school/rlm-token-auth-series-context.git
    * cd rlm-token-auth-series-context
    * code .
    * run npm install to get dependencies

  ### Part 2 end:
    * git clone -b part-2-end https://github.com/v-school/rlm-token-auth-series-context.git
    * cd rlm-token-auth-series-context
    * code .
    * run npm install to get dependencies